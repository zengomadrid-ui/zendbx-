--
-- PostgreSQL database dump
--

\restrict LxJhd2cU5uJ16I0oMrSZ2eVhoZ9ibcWBmyqyNXMFQsP6lmgARPtDeWrl4R9zVg9

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS users_update_own_posts ON public.test_posts;
DROP POLICY IF EXISTS users_read_public_posts ON public.test_posts;
DROP POLICY IF EXISTS users_read_own_posts ON public.test_posts;
DROP POLICY IF EXISTS users_insert_own_posts ON public.test_posts;
DROP POLICY IF EXISTS users_delete_own_posts ON public.test_posts;
ALTER TABLE IF EXISTS ONLY public.test_posts DROP CONSTRAINT IF EXISTS test_posts_pkey;
ALTER TABLE IF EXISTS ONLY public._nexora_metadata DROP CONSTRAINT IF EXISTS _nexora_metadata_table_name_key;
ALTER TABLE IF EXISTS ONLY public._nexora_metadata DROP CONSTRAINT IF EXISTS _nexora_metadata_pkey;
DROP TABLE IF EXISTS public.test_posts;
DROP TABLE IF EXISTS public._nexora_metadata;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS auth.owns_record(record_user_id uuid);
DROP FUNCTION IF EXISTS auth.is_service_role();
DROP FUNCTION IF EXISTS auth.is_rls_enabled(table_name text);
DROP FUNCTION IF EXISTS auth.is_authenticated();
DROP FUNCTION IF EXISTS auth.enable_rls(table_name text);
DROP FUNCTION IF EXISTS auth.disable_rls(table_name text);
DROP FUNCTION IF EXISTS auth.current_user_id();
DROP FUNCTION IF EXISTS auth."current_role"();
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pg_stat_statements;
DROP SCHEMA IF EXISTS auth;
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: current_role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth."current_role"() RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
BEGIN
    RETURN COALESCE(current_setting('app.current_role', true), 'anon');
EXCEPTION
    WHEN OTHERS THEN
        RETURN 'anon';
END;
$$;


--
-- Name: current_user_id(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.current_user_id() RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
BEGIN
    RETURN current_setting('app.current_user_id', true);
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
$$;


--
-- Name: disable_rls(text); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.disable_rls(table_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE format('ALTER TABLE %I DISABLE ROW LEVEL SECURITY', table_name);
    RAISE NOTICE 'RLS disabled on table: %', table_name;
END;
$$;


--
-- Name: enable_rls(text); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.enable_rls(table_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', table_name);
    RAISE NOTICE 'RLS enabled on table: %', table_name;
END;
$$;


--
-- Name: is_authenticated(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.is_authenticated() RETURNS boolean
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
BEGIN
    RETURN auth.current_role() IN ('authenticated', 'service_role');
END;
$$;


--
-- Name: is_rls_enabled(text); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.is_rls_enabled(table_name text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    is_enabled BOOLEAN;
BEGIN
    SELECT relrowsecurity INTO is_enabled
    FROM pg_class
    WHERE relname = table_name;
    
    RETURN COALESCE(is_enabled, false);
END;
$$;


--
-- Name: is_service_role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.is_service_role() RETURNS boolean
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
BEGIN
    RETURN auth.current_role() = 'service_role';
END;
$$;


--
-- Name: owns_record(uuid); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.owns_record(record_user_id uuid) RETURNS boolean
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
DECLARE
    current_uid TEXT;
BEGIN
    IF auth.is_service_role() THEN
        RETURN true;
    END IF;
    
    current_uid := auth.current_user_id();
    RETURN current_uid IS NOT NULL AND current_uid::UUID = record_user_id;
EXCEPTION
    WHEN OTHERS THEN
        RETURN false;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                BEGIN
                    NEW.updated_at = NOW();
                    RETURN NEW;
                END;
                $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _nexora_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._nexora_metadata (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    table_name character varying(255) NOT NULL,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: test_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.test_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title text NOT NULL,
    content text,
    is_public boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Data for Name: _nexora_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._nexora_metadata (id, table_name, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: test_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_posts (id, user_id, title, content, is_public, created_at) FROM stdin;
597ed454-138a-42ac-b2d3-f125700d272a	123e4567-e89b-12d3-a456-426614174000	Alice Private Post	Only Alice can see this	f	2026-04-13 13:40:08.22453+05:30
5e183beb-1b20-41b6-8172-aeda04328647	123e4567-e89b-12d3-a456-426614174000	Alice Public Post	Everyone can see this	t	2026-04-13 13:40:08.22453+05:30
42689ffd-4f7b-423b-a38d-d8f458722de3	223e4567-e89b-12d3-a456-426614174000	Bob Private Post	Only Bob can see this	f	2026-04-13 13:40:08.22453+05:30
3d035a13-2aa5-4c60-8785-a6c615657b94	223e4567-e89b-12d3-a456-426614174000	Bob Public Post	Everyone can see this	t	2026-04-13 13:40:08.22453+05:30
\.


--
-- Name: _nexora_metadata _nexora_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._nexora_metadata
    ADD CONSTRAINT _nexora_metadata_pkey PRIMARY KEY (id);


--
-- Name: _nexora_metadata _nexora_metadata_table_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._nexora_metadata
    ADD CONSTRAINT _nexora_metadata_table_name_key UNIQUE (table_name);


--
-- Name: test_posts test_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.test_posts
    ADD CONSTRAINT test_posts_pkey PRIMARY KEY (id);


--
-- Name: test_posts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.test_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: test_posts users_delete_own_posts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_delete_own_posts ON public.test_posts FOR DELETE USING ((auth.is_service_role() OR ((user_id)::text = auth.current_user_id())));


--
-- Name: test_posts users_insert_own_posts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_insert_own_posts ON public.test_posts FOR INSERT WITH CHECK ((auth.is_authenticated() AND ((user_id)::text = auth.current_user_id())));


--
-- Name: test_posts users_read_own_posts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_read_own_posts ON public.test_posts FOR SELECT USING ((auth.is_service_role() OR ((user_id)::text = auth.current_user_id())));


--
-- Name: test_posts users_read_public_posts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_read_public_posts ON public.test_posts FOR SELECT USING ((is_public = true));


--
-- Name: test_posts users_update_own_posts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_update_own_posts ON public.test_posts FOR UPDATE USING ((auth.is_service_role() OR ((user_id)::text = auth.current_user_id())));


--
-- PostgreSQL database dump complete
--

\unrestrict LxJhd2cU5uJ16I0oMrSZ2eVhoZ9ibcWBmyqyNXMFQsP6lmgARPtDeWrl4R9zVg9

