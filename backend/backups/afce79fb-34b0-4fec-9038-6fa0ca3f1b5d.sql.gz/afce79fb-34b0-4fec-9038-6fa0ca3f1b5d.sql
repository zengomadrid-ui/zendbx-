--
-- PostgreSQL database dump
--

\restrict pyLFt2LKJfGeFnqLtq8EqAb45bKct82Hm9rOqGjLNy2aZPLWpkTXr5MG1jf0GSl

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS test_policy ON public.rls_test;
DROP POLICY IF EXISTS shopping_cart_user_policy ON public.shopping_cart;
DROP POLICY IF EXISTS reviews_user_policy ON public.reviews;
DROP POLICY IF EXISTS orders_user_policy ON public.orders;
ALTER TABLE IF EXISTS ONLY public.standings DROP CONSTRAINT IF EXISTS fk_standings_team_id;
ALTER TABLE IF EXISTS ONLY public.standings DROP CONSTRAINT IF EXISTS fk_standings_season_id;
ALTER TABLE IF EXISTS ONLY public.seasons DROP CONSTRAINT IF EXISTS fk_seasons_league_id;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS fk_reviews_product_id;
ALTER TABLE IF EXISTS ONLY public.players DROP CONSTRAINT IF EXISTS fk_players_team_id;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS fk_order_items_product_id;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS fk_order_items_order_id;
ALTER TABLE IF EXISTS ONLY public.matches DROP CONSTRAINT IF EXISTS fk_matches_season_id;
ALTER TABLE IF EXISTS ONLY public.matches DROP CONSTRAINT IF EXISTS fk_matches_home_team_id;
ALTER TABLE IF EXISTS ONLY public.matches DROP CONSTRAINT IF EXISTS fk_matches_away_team_id;
ALTER TABLE IF EXISTS ONLY public.live_match_events DROP CONSTRAINT IF EXISTS fk_live_match_events_match_id;
ALTER TABLE IF EXISTS ONLY public.category_products DROP CONSTRAINT IF EXISTS fk_category_products_product_id;
ALTER TABLE IF EXISTS ONLY public.category_products DROP CONSTRAINT IF EXISTS fk_category_products_category_id;
DROP TRIGGER IF EXISTS standings_realtime_trigger ON public.standings;
DROP TRIGGER IF EXISTS shopping_cart_realtime_trigger ON public.shopping_cart;
DROP TRIGGER IF EXISTS matches_realtime_trigger ON public.matches;
DROP TRIGGER IF EXISTS live_match_events_realtime_trigger ON public.live_match_events;
DROP INDEX IF EXISTS public.idx_standings_season_id_team_id_0;
DROP INDEX IF EXISTS public.idx_shopping_cart_user_id_product_id_0;
DROP INDEX IF EXISTS public.idx_seasons_league_id_0;
DROP INDEX IF EXISTS public.idx_reviews_product_id_user_id_0;
DROP INDEX IF EXISTS public.idx_players_team_id_0;
DROP INDEX IF EXISTS public.idx_order_items_order_id_product_id_0;
DROP INDEX IF EXISTS public.idx_matches_season_id_home_team_id_away_team_id_0;
DROP INDEX IF EXISTS public.idx_live_match_events_match_id_0;
DROP INDEX IF EXISTS public.idx_category_products_product_id_category_id_0;
ALTER TABLE IF EXISTS ONLY public.teams DROP CONSTRAINT IF EXISTS teams_pkey;
ALTER TABLE IF EXISTS ONLY public.standings DROP CONSTRAINT IF EXISTS standings_pkey;
ALTER TABLE IF EXISTS ONLY public.shopping_cart DROP CONSTRAINT IF EXISTS shopping_cart_pkey;
ALTER TABLE IF EXISTS ONLY public.seasons DROP CONSTRAINT IF EXISTS seasons_pkey;
ALTER TABLE IF EXISTS ONLY public.rls_test DROP CONSTRAINT IF EXISTS rls_test_pkey;
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS reviews_pkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pkey;
ALTER TABLE IF EXISTS ONLY public.players DROP CONSTRAINT IF EXISTS players_pkey;
ALTER TABLE IF EXISTS ONLY public.orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE IF EXISTS ONLY public.order_items DROP CONSTRAINT IF EXISTS order_items_pkey;
ALTER TABLE IF EXISTS ONLY public.matches DROP CONSTRAINT IF EXISTS matches_pkey;
ALTER TABLE IF EXISTS ONLY public.live_match_events DROP CONSTRAINT IF EXISTS live_match_events_pkey;
ALTER TABLE IF EXISTS ONLY public.leagues DROP CONSTRAINT IF EXISTS leagues_pkey;
ALTER TABLE IF EXISTS ONLY public.category_products DROP CONSTRAINT IF EXISTS category_products_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public._nexora_metadata DROP CONSTRAINT IF EXISTS _nexora_metadata_table_name_key;
ALTER TABLE IF EXISTS ONLY public._nexora_metadata DROP CONSTRAINT IF EXISTS _nexora_metadata_pkey;
DROP TABLE IF EXISTS public.teams;
DROP TABLE IF EXISTS public.standings;
DROP TABLE IF EXISTS public.shopping_cart;
DROP TABLE IF EXISTS public.seasons;
DROP TABLE IF EXISTS public.rls_test;
DROP TABLE IF EXISTS public.reviews;
DROP TABLE IF EXISTS public.products;
DROP TABLE IF EXISTS public.players;
DROP TABLE IF EXISTS public.orders;
DROP TABLE IF EXISTS public.order_items;
DROP TABLE IF EXISTS public.matches;
DROP TABLE IF EXISTS public.live_match_events;
DROP TABLE IF EXISTS public.leagues;
DROP TABLE IF EXISTS public.category_products;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public._nexora_metadata;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.notify_database_change();
DROP FUNCTION IF EXISTS auth.owns_record(record_user_id uuid);
DROP FUNCTION IF EXISTS auth.list_policies(table_name text);
DROP FUNCTION IF EXISTS auth.is_service_role();
DROP FUNCTION IF EXISTS auth.is_rls_enabled(table_name text);
DROP FUNCTION IF EXISTS auth.is_authenticated();
DROP FUNCTION IF EXISTS auth.enable_rls(table_name text);
DROP FUNCTION IF EXISTS auth.disable_rls(table_name text);
DROP FUNCTION IF EXISTS auth.current_user_id();
DROP FUNCTION IF EXISTS auth."current_role"();
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pg_stat_statements;
DROP SCHEMA IF EXISTS auth;
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: current_role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth."current_role"() RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
BEGIN
    RETURN COALESCE(current_setting('app.current_role', true), 'anon');
EXCEPTION
    WHEN OTHERS THEN
        RETURN 'anon';
END;
$$;


--
-- Name: FUNCTION "current_role"(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth."current_role"() IS 'Returns the current user role (anon, authenticated, service_role)';


--
-- Name: current_user_id(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.current_user_id() RETURNS text
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
BEGIN
    RETURN current_setting('app.current_user_id', true);
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
$$;


--
-- Name: FUNCTION current_user_id(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.current_user_id() IS 'Returns the current user ID from session variable set by RLS middleware';


--
-- Name: disable_rls(text); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.disable_rls(table_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE format('ALTER TABLE %I DISABLE ROW LEVEL SECURITY', table_name);
    RAISE NOTICE 'RLS disabled on table: %', table_name;
END;
$$;


--
-- Name: FUNCTION disable_rls(table_name text); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.disable_rls(table_name text) IS 'Disable RLS on a table';


--
-- Name: enable_rls(text); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.enable_rls(table_name text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', table_name);
    RAISE NOTICE 'RLS enabled on table: %', table_name;
END;
$$;


--
-- Name: FUNCTION enable_rls(table_name text); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.enable_rls(table_name text) IS 'Enable RLS on a table';


--
-- Name: is_authenticated(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.is_authenticated() RETURNS boolean
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
BEGIN
    RETURN auth.current_role() IN ('authenticated', 'service_role');
END;
$$;


--
-- Name: FUNCTION is_authenticated(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.is_authenticated() IS 'Returns true if user is authenticated';


--
-- Name: is_rls_enabled(text); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.is_rls_enabled(table_name text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    is_enabled BOOLEAN;
BEGIN
    SELECT relrowsecurity INTO is_enabled
    FROM pg_class
    WHERE relname = table_name;
    
    RETURN COALESCE(is_enabled, false);
END;
$$;


--
-- Name: FUNCTION is_rls_enabled(table_name text); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.is_rls_enabled(table_name text) IS 'Check if RLS is enabled on a table';


--
-- Name: is_service_role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.is_service_role() RETURNS boolean
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
BEGIN
    RETURN auth.current_role() = 'service_role';
END;
$$;


--
-- Name: FUNCTION is_service_role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.is_service_role() IS 'Returns true if user has service_role privileges';


--
-- Name: list_policies(text); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.list_policies(table_name text) RETURNS TABLE(policy_name text, command text, permissive text, roles text[], qual text, with_check text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        pol.polname::TEXT,
        CASE pol.polcmd
            WHEN 'r' THEN 'SELECT'
            WHEN 'a' THEN 'INSERT'
            WHEN 'w' THEN 'UPDATE'
            WHEN 'd' THEN 'DELETE'
            WHEN '*' THEN 'ALL'
        END::TEXT,
        CASE pol.polpermissive
            WHEN true THEN 'PERMISSIVE'
            ELSE 'RESTRICTIVE'
        END::TEXT,
        ARRAY(
            SELECT rolname::TEXT
            FROM pg_roles
            WHERE oid = ANY(pol.polroles)
        ),
        pg_get_expr(pol.polqual, pol.polrelid)::TEXT,
        pg_get_expr(pol.polwithcheck, pol.polrelid)::TEXT
    FROM pg_policy pol
    JOIN pg_class cls ON pol.polrelid = cls.oid
    WHERE cls.relname = table_name;
END;
$$;


--
-- Name: FUNCTION list_policies(table_name text); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.list_policies(table_name text) IS 'List all RLS policies on a table';


--
-- Name: owns_record(uuid); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.owns_record(record_user_id uuid) RETURNS boolean
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    AS $$
DECLARE
    current_uid TEXT;
BEGIN
    IF auth.is_service_role() THEN
        RETURN true;
    END IF;
    
    current_uid := auth.current_user_id();
    RETURN current_uid IS NOT NULL AND current_uid::UUID = record_user_id;
EXCEPTION
    WHEN OTHERS THEN
        RETURN false;
END;
$$;


--
-- Name: FUNCTION owns_record(record_user_id uuid); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.owns_record(record_user_id uuid) IS 'Returns true if current user owns the record';


--
-- Name: notify_database_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_database_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                        BEGIN
                            PERFORM pg_notify(
                                'database_changes',
                                json_build_object(
                                    'table', TG_TABLE_NAME,
                                    'action', TG_OP,
                                    'data', row_to_json(NEW)
                                )::text
                            );
                            RETURN NEW;
                        END;
                        $$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                BEGIN
                    NEW.updated_at = NOW();
                    RETURN NEW;
                END;
                $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _nexora_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._nexora_metadata (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    table_name character varying(255) NOT NULL,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: category_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.category_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    category_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: leagues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leagues (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    country text,
    season text,
    start_date date,
    end_date date,
    total_teams integer,
    status text DEFAULT 'upcoming'::text
);


--
-- Name: live_match_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_match_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    match_id uuid NOT NULL,
    event_type text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    season_id uuid NOT NULL,
    home_team_id uuid NOT NULL,
    away_team_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    order_date timestamp without time zone NOT NULL,
    total numeric(10,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.players (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    team_id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    user_id uuid NOT NULL,
    rating integer NOT NULL,
    review text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: rls_test; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rls_test (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    message text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: seasons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seasons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    league_id uuid NOT NULL,
    year integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: shopping_cart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_cart (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: standings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.standings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    season_id uuid NOT NULL,
    team_id uuid NOT NULL,
    points integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: _nexora_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._nexora_metadata (id, table_name, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: category_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.category_products (id, product_id, category_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: leagues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leagues (id, name, created_at, updated_at, country, season, start_date, end_date, total_teams, status) FROM stdin;
f40d6489-d80f-466e-96cf-a992387446f9	La Liga	2026-04-23 12:16:55.91831	2026-04-23 12:23:51.28042	Spain	2024/2025	2024-08-15	2025-05-25	20	ongoing
4ffc595b-1544-46f3-b8a2-8bdcb39f064c	Serie A	2026-04-23 12:16:55.91831	2026-04-23 12:23:51.28042	Italy	2024/2025	2024-08-18	2025-05-22	20	ongoing
89062aa2-f242-4dd8-a43d-39d4a9c45ec9	Bundesliga	2026-04-23 12:16:55.91831	2026-04-23 12:23:51.28042	Germany	2024/2025	2024-08-20	2025-05-18	18	ongoing
30cda288-248f-46c3-bd2a-fedb2ba5094e	Premier Leagu	2026-04-23 12:16:55.91831	2026-04-23 12:23:51.28042	Unknown	2024/2025	\N	\N	20	ongoing
a8aa9844-8b4a-4500-b2e2-90677e315bce	isl	2026-04-23 12:17:44.272344	2026-04-23 12:23:51.28042	Unknown	2024/2025	\N	\N	20	ongoing
\.


--
-- Data for Name: live_match_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.live_match_events (id, match_id, event_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matches (id, season_id, home_team_id, away_team_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, product_id, quantity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, user_id, order_date, total, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.players (id, team_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, description, price, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reviews (id, product_id, user_id, rating, review, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rls_test; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rls_test (id, user_id, message, created_at) FROM stdin;
b1b99f6b-50c9-4f3c-a13c-4944e400668b	123e4567-e89b-12d3-a456-426614174000	Test message 1	2026-04-13 12:11:59.755195+05:30
2c2a8cd9-e186-4e5a-8de5-141b05a184f0	223e4567-e89b-12d3-a456-426614174000	Test message 2	2026-04-13 12:11:59.755195+05:30
\.


--
-- Data for Name: seasons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seasons (id, league_id, year, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shopping_cart; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shopping_cart (id, user_id, product_id, quantity, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: standings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.standings (id, season_id, team_id, points, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teams (id, name, created_at, updated_at) FROM stdin;
\.


--
-- Name: _nexora_metadata _nexora_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._nexora_metadata
    ADD CONSTRAINT _nexora_metadata_pkey PRIMARY KEY (id);


--
-- Name: _nexora_metadata _nexora_metadata_table_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._nexora_metadata
    ADD CONSTRAINT _nexora_metadata_table_name_key UNIQUE (table_name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: category_products category_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_products
    ADD CONSTRAINT category_products_pkey PRIMARY KEY (id);


--
-- Name: leagues leagues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leagues
    ADD CONSTRAINT leagues_pkey PRIMARY KEY (id);


--
-- Name: live_match_events live_match_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_match_events
    ADD CONSTRAINT live_match_events_pkey PRIMARY KEY (id);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: rls_test rls_test_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rls_test
    ADD CONSTRAINT rls_test_pkey PRIMARY KEY (id);


--
-- Name: seasons seasons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasons
    ADD CONSTRAINT seasons_pkey PRIMARY KEY (id);


--
-- Name: shopping_cart shopping_cart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_cart
    ADD CONSTRAINT shopping_cart_pkey PRIMARY KEY (id);


--
-- Name: standings standings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.standings
    ADD CONSTRAINT standings_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: idx_category_products_product_id_category_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_category_products_product_id_category_id_0 ON public.category_products USING btree (product_id, category_id);


--
-- Name: idx_live_match_events_match_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_live_match_events_match_id_0 ON public.live_match_events USING btree (match_id);


--
-- Name: idx_matches_season_id_home_team_id_away_team_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_matches_season_id_home_team_id_away_team_id_0 ON public.matches USING btree (season_id, home_team_id, away_team_id);


--
-- Name: idx_order_items_order_id_product_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_items_order_id_product_id_0 ON public.order_items USING btree (order_id, product_id);


--
-- Name: idx_players_team_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_team_id_0 ON public.players USING btree (team_id);


--
-- Name: idx_reviews_product_id_user_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reviews_product_id_user_id_0 ON public.reviews USING btree (product_id, user_id);


--
-- Name: idx_seasons_league_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_seasons_league_id_0 ON public.seasons USING btree (league_id);


--
-- Name: idx_shopping_cart_user_id_product_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shopping_cart_user_id_product_id_0 ON public.shopping_cart USING btree (user_id, product_id);


--
-- Name: idx_standings_season_id_team_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_standings_season_id_team_id_0 ON public.standings USING btree (season_id, team_id);


--
-- Name: live_match_events live_match_events_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER live_match_events_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.live_match_events FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- Name: matches matches_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER matches_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.matches FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- Name: shopping_cart shopping_cart_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER shopping_cart_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.shopping_cart FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- Name: standings standings_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER standings_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.standings FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- Name: category_products fk_category_products_category_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_products
    ADD CONSTRAINT fk_category_products_category_id FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: category_products fk_category_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category_products
    ADD CONSTRAINT fk_category_products_product_id FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: live_match_events fk_live_match_events_match_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_match_events
    ADD CONSTRAINT fk_live_match_events_match_id FOREIGN KEY (match_id) REFERENCES public.matches(id) ON DELETE CASCADE;


--
-- Name: matches fk_matches_away_team_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT fk_matches_away_team_id FOREIGN KEY (away_team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: matches fk_matches_home_team_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT fk_matches_home_team_id FOREIGN KEY (home_team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: matches fk_matches_season_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT fk_matches_season_id FOREIGN KEY (season_id) REFERENCES public.seasons(id) ON DELETE CASCADE;


--
-- Name: order_items fk_order_items_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fk_order_items_order_id FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items fk_order_items_product_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fk_order_items_product_id FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: players fk_players_team_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT fk_players_team_id FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: reviews fk_reviews_product_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT fk_reviews_product_id FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: seasons fk_seasons_league_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasons
    ADD CONSTRAINT fk_seasons_league_id FOREIGN KEY (league_id) REFERENCES public.leagues(id) ON DELETE CASCADE;


--
-- Name: standings fk_standings_season_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.standings
    ADD CONSTRAINT fk_standings_season_id FOREIGN KEY (season_id) REFERENCES public.seasons(id) ON DELETE CASCADE;


--
-- Name: standings fk_standings_team_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.standings
    ADD CONSTRAINT fk_standings_team_id FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: order_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

--
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

--
-- Name: orders orders_user_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY orders_user_policy ON public.orders USING ((auth.is_service_role() OR ((user_id)::text = auth.current_user_id())));


--
-- Name: reviews; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: reviews reviews_user_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY reviews_user_policy ON public.reviews USING ((auth.is_service_role() OR ((user_id)::text = auth.current_user_id())));


--
-- Name: rls_test; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rls_test ENABLE ROW LEVEL SECURITY;

--
-- Name: shopping_cart; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.shopping_cart ENABLE ROW LEVEL SECURITY;

--
-- Name: shopping_cart shopping_cart_user_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY shopping_cart_user_policy ON public.shopping_cart USING ((auth.is_service_role() OR ((user_id)::text = auth.current_user_id())));


--
-- Name: rls_test test_policy; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY test_policy ON public.rls_test FOR SELECT USING ((auth.is_service_role() OR ((user_id)::text = auth.current_user_id())));


--
-- PostgreSQL database dump complete
--

\unrestrict pyLFt2LKJfGeFnqLtq8EqAb45bKct82Hm9rOqGjLNy2aZPLWpkTXr5MG1jf0GSl

