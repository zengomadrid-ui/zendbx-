--
-- PostgreSQL database dump
--

\restrict ClgLNt0ilE2VECz5ultPYMgic8kmYCnTvulCl06LjFcMx30rg5xxkLdhA2DVUw3

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.typing_indicators DROP CONSTRAINT IF EXISTS fk_typing_indicators_user_id;
ALTER TABLE IF EXISTS ONLY public.typing_indicators DROP CONSTRAINT IF EXISTS fk_typing_indicators_channel_id;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS fk_tasks_category_id;
ALTER TABLE IF EXISTS ONLY public.online_status DROP CONSTRAINT IF EXISTS fk_online_status_user_id;
ALTER TABLE IF EXISTS ONLY public.online_status DROP CONSTRAINT IF EXISTS fk_online_status_channel_id;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS fk_messages_user_id;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS fk_messages_channel_id;
DROP TRIGGER IF EXISTS typing_indicators_realtime_trigger ON public.typing_indicators;
DROP TRIGGER IF EXISTS tasks_realtime_trigger ON public.tasks;
DROP TRIGGER IF EXISTS online_status_realtime_trigger ON public.online_status;
DROP TRIGGER IF EXISTS messages_realtime_trigger ON public.messages;
DROP TRIGGER IF EXISTS channels_realtime_trigger ON public.channels;
DROP INDEX IF EXISTS public.idx_users_username_0;
DROP INDEX IF EXISTS public.idx_users_email_1;
DROP INDEX IF EXISTS public.idx_typing_indicators_user_id_1;
DROP INDEX IF EXISTS public.idx_typing_indicators_channel_id_0;
DROP INDEX IF EXISTS public.idx_tasks_category_id_0;
DROP INDEX IF EXISTS public.idx_online_status_user_id_0;
DROP INDEX IF EXISTS public.idx_online_status_channel_id_1;
DROP INDEX IF EXISTS public.idx_messages_user_id_1;
DROP INDEX IF EXISTS public.idx_messages_channel_id_0;
DROP INDEX IF EXISTS public.idx_channels_name_0;
DROP INDEX IF EXISTS public.idx_categories_name_0;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.typing_indicators DROP CONSTRAINT IF EXISTS typing_indicators_pkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.online_status DROP CONSTRAINT IF EXISTS online_status_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.channels DROP CONSTRAINT IF EXISTS channels_pkey;
ALTER TABLE IF EXISTS ONLY public.channels DROP CONSTRAINT IF EXISTS channels_name_key;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public._nexora_metadata DROP CONSTRAINT IF EXISTS _nexora_metadata_table_name_key;
ALTER TABLE IF EXISTS ONLY public._nexora_metadata DROP CONSTRAINT IF EXISTS _nexora_metadata_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.typing_indicators;
DROP TABLE IF EXISTS public.tasks;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.online_status;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.channels;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public._nexora_metadata;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.notify_database_change();
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pg_stat_statements;
--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: notify_database_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_database_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                        BEGIN
                            PERFORM pg_notify(
                                'database_changes',
                                json_build_object(
                                    'table', TG_TABLE_NAME,
                                    'action', TG_OP,
                                    'data', row_to_json(NEW)
                                )::text
                            );
                            RETURN NEW;
                        END;
                        $$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                BEGIN
                    NEW.updated_at = NOW();
                    RETURN NEW;
                END;
                $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _nexora_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._nexora_metadata (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    table_name character varying(255) NOT NULL,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid NOT NULL,
    user_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    typing_status boolean DEFAULT false NOT NULL
);


--
-- Name: online_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.online_status (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    status boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    status text DEFAULT 'active'::text,
    user_id uuid,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: typing_indicators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.typing_indicators (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid NOT NULL,
    user_id uuid NOT NULL,
    is_typing boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: _nexora_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._nexora_metadata (id, table_name, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channels (id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, channel_id, user_id, content, created_at, updated_at, typing_status) FROM stdin;
\.


--
-- Data for Name: online_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.online_status (id, user_id, channel_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, name, status, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (id, category_id, name, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: typing_indicators; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.typing_indicators (id, channel_id, user_id, is_typing, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password, created_at, updated_at) FROM stdin;
\.


--
-- Name: _nexora_metadata _nexora_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._nexora_metadata
    ADD CONSTRAINT _nexora_metadata_pkey PRIMARY KEY (id);


--
-- Name: _nexora_metadata _nexora_metadata_table_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._nexora_metadata
    ADD CONSTRAINT _nexora_metadata_table_name_key UNIQUE (table_name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: channels channels_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_name_key UNIQUE (name);


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: online_status online_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_status
    ADD CONSTRAINT online_status_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: typing_indicators typing_indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.typing_indicators
    ADD CONSTRAINT typing_indicators_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_categories_name_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_categories_name_0 ON public.categories USING btree (name);


--
-- Name: idx_channels_name_0; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_channels_name_0 ON public.channels USING btree (name);


--
-- Name: idx_messages_channel_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_channel_id_0 ON public.messages USING btree (channel_id);


--
-- Name: idx_messages_user_id_1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_user_id_1 ON public.messages USING btree (user_id);


--
-- Name: idx_online_status_channel_id_1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_online_status_channel_id_1 ON public.online_status USING btree (channel_id);


--
-- Name: idx_online_status_user_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_online_status_user_id_0 ON public.online_status USING btree (user_id);


--
-- Name: idx_tasks_category_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_category_id_0 ON public.tasks USING btree (category_id);


--
-- Name: idx_typing_indicators_channel_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_typing_indicators_channel_id_0 ON public.typing_indicators USING btree (channel_id);


--
-- Name: idx_typing_indicators_user_id_1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_typing_indicators_user_id_1 ON public.typing_indicators USING btree (user_id);


--
-- Name: idx_users_email_1; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_users_email_1 ON public.users USING btree (email);


--
-- Name: idx_users_username_0; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_users_username_0 ON public.users USING btree (username);


--
-- Name: channels channels_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER channels_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.channels FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- Name: messages messages_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER messages_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.messages FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- Name: online_status online_status_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER online_status_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.online_status FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- Name: tasks tasks_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tasks_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- Name: typing_indicators typing_indicators_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER typing_indicators_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.typing_indicators FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- Name: messages fk_messages_channel_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_messages_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE CASCADE;


--
-- Name: messages fk_messages_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_messages_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: online_status fk_online_status_channel_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_status
    ADD CONSTRAINT fk_online_status_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE CASCADE;


--
-- Name: online_status fk_online_status_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_status
    ADD CONSTRAINT fk_online_status_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tasks fk_tasks_category_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_tasks_category_id FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: typing_indicators fk_typing_indicators_channel_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.typing_indicators
    ADD CONSTRAINT fk_typing_indicators_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE CASCADE;


--
-- Name: typing_indicators fk_typing_indicators_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.typing_indicators
    ADD CONSTRAINT fk_typing_indicators_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: projects projects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: channels; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channels ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: online_status; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.online_status ENABLE ROW LEVEL SECURITY;

--
-- Name: tasks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: typing_indicators; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.typing_indicators ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict ClgLNt0ilE2VECz5ultPYMgic8kmYCnTvulCl06LjFcMx30rg5xxkLdhA2DVUw3

