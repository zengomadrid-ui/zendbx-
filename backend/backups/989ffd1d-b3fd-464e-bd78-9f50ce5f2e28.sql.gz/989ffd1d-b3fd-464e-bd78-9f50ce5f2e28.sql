--
-- PostgreSQL database dump
--

\restrict NcbnQ07u6ienQ2Y89Ofz84haxd9aDcaUJRFCbAvPgNIGCVbEumdRtfmkPX0Yv0m

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

-- Started on 2026-05-13 13:28:09

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public._nexora_metadata DROP CONSTRAINT IF EXISTS _nexora_metadata_table_name_key;
ALTER TABLE IF EXISTS ONLY public._nexora_metadata DROP CONSTRAINT IF EXISTS _nexora_metadata_pkey;
DROP TABLE IF EXISTS public._nexora_metadata;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pg_stat_statements;
--
-- TOC entry 3 (class 3079 OID 60331)
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- TOC entry 3353 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- TOC entry 2 (class 3079 OID 60320)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 3354 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 229 (class 1255 OID 60362)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                BEGIN
                    NEW.updated_at = NOW();
                    RETURN NEW;
                END;
                $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 60363)
-- Name: _nexora_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._nexora_metadata (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    table_name character varying(255) NOT NULL,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 3347 (class 0 OID 60363)
-- Dependencies: 218
-- Data for Name: _nexora_metadata; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3200 (class 2606 OID 60372)
-- Name: _nexora_metadata _nexora_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._nexora_metadata
    ADD CONSTRAINT _nexora_metadata_pkey PRIMARY KEY (id);


--
-- TOC entry 3202 (class 2606 OID 60374)
-- Name: _nexora_metadata _nexora_metadata_table_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._nexora_metadata
    ADD CONSTRAINT _nexora_metadata_table_name_key UNIQUE (table_name);


-- Completed on 2026-05-13 13:28:10

--
-- PostgreSQL database dump complete
--

\unrestrict NcbnQ07u6ienQ2Y89Ofz84haxd9aDcaUJRFCbAvPgNIGCVbEumdRtfmkPX0Yv0m

