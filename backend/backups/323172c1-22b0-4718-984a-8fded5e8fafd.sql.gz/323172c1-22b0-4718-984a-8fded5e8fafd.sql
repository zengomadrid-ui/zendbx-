--
-- PostgreSQL database dump
--

\restrict AzQzG3jIkrh9PTTogdUUHdbmHmdONETxdF4BUNiHela8Qcasc87ijqRl29BM1F0

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

-- Started on 2026-05-13 13:29:28

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.results DROP CONSTRAINT IF EXISTS results_team_id_fkey;
ALTER TABLE IF EXISTS ONLY public.results DROP CONSTRAINT IF EXISTS results_race_id_fkey;
ALTER TABLE IF EXISTS ONLY public.results DROP CONSTRAINT IF EXISTS results_driver_id_fkey;
ALTER TABLE IF EXISTS ONLY public.races DROP CONSTRAINT IF EXISTS races_circuit_id_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.typing_indicators DROP CONSTRAINT IF EXISTS fk_typing_indicators_user_id;
ALTER TABLE IF EXISTS ONLY public.typing_indicators DROP CONSTRAINT IF EXISTS fk_typing_indicators_channel_id;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS fk_transactions_account_id;
ALTER TABLE IF EXISTS ONLY public.tickets DROP CONSTRAINT IF EXISTS fk_tickets_event_id;
ALTER TABLE IF EXISTS ONLY public.online_status DROP CONSTRAINT IF EXISTS fk_online_status_user_id;
ALTER TABLE IF EXISTS ONLY public.online_status DROP CONSTRAINT IF EXISTS fk_online_status_channel_id;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS fk_messages_user_id;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS fk_messages_channel_id;
ALTER TABLE IF EXISTS ONLY public.check_ins DROP CONSTRAINT IF EXISTS fk_check_ins_ticket_id;
ALTER TABLE IF EXISTS ONLY public.check_ins DROP CONSTRAINT IF EXISTS fk_check_ins_event_id;
ALTER TABLE IF EXISTS ONLY public.check_ins DROP CONSTRAINT IF EXISTS fk_check_ins_attendee_id;
ALTER TABLE IF EXISTS ONLY public.attendees DROP CONSTRAINT IF EXISTS fk_attendees_user_id;
ALTER TABLE IF EXISTS ONLY public.attendees DROP CONSTRAINT IF EXISTS fk_attendees_event_id;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS fk_accounts_user_id;
ALTER TABLE IF EXISTS ONLY public.drivers DROP CONSTRAINT IF EXISTS drivers_team_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cricket_players DROP CONSTRAINT IF EXISTS cricket_players_team_id_fkey;
DROP TRIGGER IF EXISTS typing_indicators_realtime_trigger ON public.typing_indicators;
DROP TRIGGER IF EXISTS transactions_realtime_trigger ON public.transactions;
DROP TRIGGER IF EXISTS tasks_realtime_trigger ON public.tasks;
DROP TRIGGER IF EXISTS online_status_realtime_trigger ON public.online_status;
DROP TRIGGER IF EXISTS messages_realtime_trigger ON public.messages;
DROP TRIGGER IF EXISTS matches_realtime_trigger ON public.matches;
DROP TRIGGER IF EXISTS cricket_players_trigger ON public.cricket_players;
DROP TRIGGER IF EXISTS check_ins_realtime_trigger ON public.check_ins;
DROP TRIGGER IF EXISTS channels_realtime_trigger ON public.channels;
DROP TRIGGER IF EXISTS attendees_realtime_trigger ON public.attendees;
DROP TRIGGER IF EXISTS accounts_realtime_trigger ON public.accounts;
DROP INDEX IF EXISTS public.idx_users_username_0;
DROP INDEX IF EXISTS public.idx_users_email_1;
DROP INDEX IF EXISTS public.idx_users_email_0;
DROP INDEX IF EXISTS public.idx_typing_indicators_user_id_1;
DROP INDEX IF EXISTS public.idx_typing_indicators_channel_id_0;
DROP INDEX IF EXISTS public.idx_transactions_account_id_0;
DROP INDEX IF EXISTS public.idx_tickets_event_id_0;
DROP INDEX IF EXISTS public.idx_tasks_category_id_0;
DROP INDEX IF EXISTS public.idx_online_status_user_id_0;
DROP INDEX IF EXISTS public.idx_online_status_channel_id_1;
DROP INDEX IF EXISTS public.idx_messages_user_id_1;
DROP INDEX IF EXISTS public.idx_messages_channel_id_0;
DROP INDEX IF EXISTS public.idx_fighters_weight_class_0;
DROP INDEX IF EXISTS public.idx_check_ins_ticket_id_2;
DROP INDEX IF EXISTS public.idx_check_ins_event_id_0;
DROP INDEX IF EXISTS public.idx_check_ins_attendee_id_1;
DROP INDEX IF EXISTS public.idx_channels_name_0;
DROP INDEX IF EXISTS public.idx_attendees_user_id_1;
DROP INDEX IF EXISTS public.idx_attendees_event_id_0;
DROP INDEX IF EXISTS public.idx_arenas_name_0;
DROP INDEX IF EXISTS public.idx_accounts_user_id_1;
DROP INDEX IF EXISTS public.idx_accounts_account_number_0;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.typing_indicators DROP CONSTRAINT IF EXISTS typing_indicators_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.tickets DROP CONSTRAINT IF EXISTS tickets_pkey;
ALTER TABLE IF EXISTS ONLY public.teams DROP CONSTRAINT IF EXISTS teams_pkey;
ALTER TABLE IF EXISTS ONLY public.teams DROP CONSTRAINT IF EXISTS teams_name_key;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.results DROP CONSTRAINT IF EXISTS results_race_id_driver_id_key;
ALTER TABLE IF EXISTS ONLY public.results DROP CONSTRAINT IF EXISTS results_pkey;
ALTER TABLE IF EXISTS ONLY public.races DROP CONSTRAINT IF EXISTS races_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.posts DROP CONSTRAINT IF EXISTS posts_pkey;
ALTER TABLE IF EXISTS ONLY public.players DROP CONSTRAINT IF EXISTS players_pkey;
ALTER TABLE IF EXISTS ONLY public.online_status DROP CONSTRAINT IF EXISTS online_status_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.matches DROP CONSTRAINT IF EXISTS matches_pkey;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS likes_pkey;
ALTER TABLE IF EXISTS ONLY public.follows DROP CONSTRAINT IF EXISTS follows_pkey;
ALTER TABLE IF EXISTS ONLY public.fighters DROP CONSTRAINT IF EXISTS fighters_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.drivers DROP CONSTRAINT IF EXISTS drivers_pkey;
ALTER TABLE IF EXISTS ONLY public.cricket_teams DROP CONSTRAINT IF EXISTS cricket_teams_pkey;
ALTER TABLE IF EXISTS ONLY public.cricket_players DROP CONSTRAINT IF EXISTS cricket_players_pkey;
ALTER TABLE IF EXISTS ONLY public.countrys DROP CONSTRAINT IF EXISTS countrys_pkey;
ALTER TABLE IF EXISTS ONLY public.countries DROP CONSTRAINT IF EXISTS countries_pkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_pkey;
ALTER TABLE IF EXISTS ONLY public.colleges DROP CONSTRAINT IF EXISTS colleges_pkey;
ALTER TABLE IF EXISTS ONLY public.circuits DROP CONSTRAINT IF EXISTS circuits_pkey;
ALTER TABLE IF EXISTS ONLY public.check_ins DROP CONSTRAINT IF EXISTS check_ins_pkey;
ALTER TABLE IF EXISTS ONLY public.channels DROP CONSTRAINT IF EXISTS channels_pkey;
ALTER TABLE IF EXISTS ONLY public.channels DROP CONSTRAINT IF EXISTS channels_name_key;
ALTER TABLE IF EXISTS ONLY public.attendees DROP CONSTRAINT IF EXISTS attendees_pkey;
ALTER TABLE IF EXISTS ONLY public.arenas DROP CONSTRAINT IF EXISTS arenas_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_account_number_key;
ALTER TABLE IF EXISTS ONLY public._nexora_metadata DROP CONSTRAINT IF EXISTS _nexora_metadata_table_name_key;
ALTER TABLE IF EXISTS ONLY public._nexora_metadata DROP CONSTRAINT IF EXISTS _nexora_metadata_pkey;
ALTER TABLE IF EXISTS public.teams ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.results ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.races ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.players ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.matches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.drivers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cricket_teams ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cricket_players ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.circuits ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.typing_indicators;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.tickets;
DROP SEQUENCE IF EXISTS public.teams_id_seq;
DROP TABLE IF EXISTS public.teams;
DROP TABLE IF EXISTS public.tasks;
DROP SEQUENCE IF EXISTS public.results_id_seq;
DROP TABLE IF EXISTS public.results;
DROP SEQUENCE IF EXISTS public.races_id_seq;
DROP TABLE IF EXISTS public.races;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.posts;
DROP SEQUENCE IF EXISTS public.players_id_seq;
DROP TABLE IF EXISTS public.players;
DROP TABLE IF EXISTS public.online_status;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.messages;
DROP SEQUENCE IF EXISTS public.matches_id_seq;
DROP TABLE IF EXISTS public.matches;
DROP TABLE IF EXISTS public.likes;
DROP TABLE IF EXISTS public.follows;
DROP TABLE IF EXISTS public.fighters;
DROP TABLE IF EXISTS public.events;
DROP SEQUENCE IF EXISTS public.drivers_id_seq;
DROP TABLE IF EXISTS public.drivers;
DROP SEQUENCE IF EXISTS public.cricket_teams_id_seq;
DROP TABLE IF EXISTS public.cricket_teams;
DROP SEQUENCE IF EXISTS public.cricket_players_id_seq;
DROP TABLE IF EXISTS public.cricket_players;
DROP TABLE IF EXISTS public.countrys;
DROP TABLE IF EXISTS public.countries;
DROP TABLE IF EXISTS public.comments;
DROP TABLE IF EXISTS public.colleges;
DROP SEQUENCE IF EXISTS public.circuits_id_seq;
DROP TABLE IF EXISTS public.circuits;
DROP TABLE IF EXISTS public.check_ins;
DROP TABLE IF EXISTS public.channels;
DROP TABLE IF EXISTS public.attendees;
DROP TABLE IF EXISTS public.arenas;
DROP TABLE IF EXISTS public.accounts;
DROP TABLE IF EXISTS public._nexora_metadata;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.notify_database_change();
DROP FUNCTION IF EXISTS public.notify_cricket_change();
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pg_stat_statements;
--
-- TOC entry 3 (class 3079 OID 59308)
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- TOC entry 3755 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- TOC entry 2 (class 3079 OID 59297)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 3756 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 272 (class 1255 OID 60238)
-- Name: notify_cricket_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_cricket_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM pg_notify(
        'cricket_changes',
        json_build_object(
            'table', TG_TABLE_NAME,
            'action', TG_OP,
            'data', CASE 
                        WHEN TG_OP = 'DELETE' THEN row_to_json(OLD)
                        ELSE row_to_json(NEW)
                    END
        )::text
    );
    RETURN NEW;
END;
$$;


--
-- TOC entry 271 (class 1255 OID 59435)
-- Name: notify_database_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_database_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                        BEGIN
                            PERFORM pg_notify(
                                'database_changes',
                                json_build_object(
                                    'table', TG_TABLE_NAME,
                                    'action', TG_OP,
                                    'data', row_to_json(NEW)
                                )::text
                            );
                            RETURN NEW;
                        END;
                        $$;


--
-- TOC entry 270 (class 1255 OID 59339)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                BEGIN
                    NEW.updated_at = NOW();
                    RETURN NEW;
                END;
                $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 59340)
-- Name: _nexora_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._nexora_metadata (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    table_name character varying(255) NOT NULL,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 255 (class 1259 OID 60199)
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    account_number text NOT NULL,
    balance integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 253 (class 1259 OID 60097)
-- Name: arenas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.arenas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    capacity integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 59907)
-- Name: attendees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendees (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 221 (class 1259 OID 59451)
-- Name: channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 248 (class 1259 OID 59925)
-- Name: check_ins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.check_ins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id uuid NOT NULL,
    attendee_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 240 (class 1259 OID 59795)
-- Name: circuits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.circuits (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    location character varying(100),
    country character varying(100),
    length_km numeric(5,2),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 239 (class 1259 OID 59794)
-- Name: circuits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.circuits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3757 (class 0 OID 0)
-- Dependencies: 239
-- Name: circuits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.circuits_id_seq OWNED BY public.circuits.id;


--
-- TOC entry 259 (class 1259 OID 60256)
-- Name: colleges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.colleges (
    id uuid NOT NULL,
    college_name text NOT NULL,
    department text NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 59614)
-- Name: comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    content text NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 258 (class 1259 OID 60249)
-- Name: countries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.countries (
    id uuid NOT NULL,
    country_name text NOT NULL,
    population integer,
    capital text
);


--
-- TOC entry 257 (class 1259 OID 60242)
-- Name: countrys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.countrys (
    id uuid NOT NULL,
    countri_name text NOT NULL,
    population integer,
    capital text
);


--
-- TOC entry 252 (class 1259 OID 60084)
-- Name: cricket_players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cricket_players (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    age integer,
    role character varying(50),
    team_id integer,
    runs integer DEFAULT 0,
    wickets integer DEFAULT 0
);


--
-- TOC entry 251 (class 1259 OID 60083)
-- Name: cricket_players_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cricket_players_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3758 (class 0 OID 0)
-- Dependencies: 251
-- Name: cricket_players_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cricket_players_id_seq OWNED BY public.cricket_players.id;


--
-- TOC entry 250 (class 1259 OID 60075)
-- Name: cricket_teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cricket_teams (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    country character varying(100),
    trophies integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 249 (class 1259 OID 60074)
-- Name: cricket_teams_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cricket_teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3759 (class 0 OID 0)
-- Dependencies: 249
-- Name: cricket_teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cricket_teams_id_seq OWNED BY public.cricket_teams.id;


--
-- TOC entry 238 (class 1259 OID 59782)
-- Name: drivers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drivers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    nationality character varying(100),
    date_of_birth date,
    team_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 237 (class 1259 OID 59781)
-- Name: drivers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.drivers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3760 (class 0 OID 0)
-- Dependencies: 237
-- Name: drivers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.drivers_id_seq OWNED BY public.drivers.id;


--
-- TOC entry 245 (class 1259 OID 59897)
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 254 (class 1259 OID 60107)
-- Name: fighters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fighters (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    weight_class text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 229 (class 1259 OID 59630)
-- Name: follows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.follows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    followed_user_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 59623)
-- Name: likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 59671)
-- Name: matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matches (
    id integer NOT NULL,
    home_team_id integer NOT NULL,
    away_team_id integer NOT NULL,
    match_date date NOT NULL,
    home_score integer DEFAULT 0,
    away_score integer DEFAULT 0,
    CONSTRAINT matches_check CHECK ((home_team_id <> away_team_id))
);


--
-- TOC entry 233 (class 1259 OID 59670)
-- Name: matches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3761 (class 0 OID 0)
-- Dependencies: 233
-- Name: matches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matches_id_seq OWNED BY public.matches.id;


--
-- TOC entry 222 (class 1259 OID 59463)
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid NOT NULL,
    user_id uuid NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    typing_status boolean DEFAULT false NOT NULL
);


--
-- TOC entry 230 (class 1259 OID 59637)
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 59474)
-- Name: online_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.online_status (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    channel_id uuid NOT NULL,
    status boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 232 (class 1259 OID 59657)
-- Name: players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.players (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    age integer,
    "position" character varying(50),
    team_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT players_age_check CHECK ((age > 15))
);


--
-- TOC entry 231 (class 1259 OID 59656)
-- Name: players_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.players_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3762 (class 0 OID 0)
-- Dependencies: 231
-- Name: players_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.players_id_seq OWNED BY public.players.id;


--
-- TOC entry 226 (class 1259 OID 59605)
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    content text NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 59590)
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    status text DEFAULT 'active'::text,
    user_id uuid,
    created_at timestamp without time zone DEFAULT now()
);


--
-- TOC entry 242 (class 1259 OID 59803)
-- Name: races; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.races (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    race_date date NOT NULL,
    circuit_id integer,
    season integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 241 (class 1259 OID 59802)
-- Name: races_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.races_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3763 (class 0 OID 0)
-- Dependencies: 241
-- Name: races_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.races_id_seq OWNED BY public.races.id;


--
-- TOC entry 244 (class 1259 OID 59816)
-- Name: results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.results (
    id integer NOT NULL,
    race_id integer,
    driver_id integer,
    team_id integer,
    "position" integer,
    points numeric(4,1),
    laps_completed integer,
    race_time interval,
    status character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 243 (class 1259 OID 59815)
-- Name: results_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3764 (class 0 OID 0)
-- Dependencies: 243
-- Name: results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.results_id_seq OWNED BY public.results.id;


--
-- TOC entry 219 (class 1259 OID 59418)
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 59772)
-- Name: teams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teams (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    base_country character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 235 (class 1259 OID 59771)
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3765 (class 0 OID 0)
-- Dependencies: 235
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- TOC entry 247 (class 1259 OID 59915)
-- Name: tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id uuid NOT NULL,
    name text NOT NULL,
    price integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 256 (class 1259 OID 60211)
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    account_id uuid NOT NULL,
    amount integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 59514)
-- Name: typing_indicators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.typing_indicators (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid NOT NULL,
    user_id uuid NOT NULL,
    is_typing boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 220 (class 1259 OID 59437)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 3380 (class 2604 OID 59798)
-- Name: circuits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits ALTER COLUMN id SET DEFAULT nextval('public.circuits_id_seq'::regclass);


--
-- TOC entry 3401 (class 2604 OID 60087)
-- Name: cricket_players id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cricket_players ALTER COLUMN id SET DEFAULT nextval('public.cricket_players_id_seq'::regclass);


--
-- TOC entry 3398 (class 2604 OID 60078)
-- Name: cricket_teams id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cricket_teams ALTER COLUMN id SET DEFAULT nextval('public.cricket_teams_id_seq'::regclass);


--
-- TOC entry 3378 (class 2604 OID 59785)
-- Name: drivers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drivers ALTER COLUMN id SET DEFAULT nextval('public.drivers_id_seq'::regclass);


--
-- TOC entry 3373 (class 2604 OID 59674)
-- Name: matches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches ALTER COLUMN id SET DEFAULT nextval('public.matches_id_seq'::regclass);


--
-- TOC entry 3371 (class 2604 OID 59660)
-- Name: players id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players ALTER COLUMN id SET DEFAULT nextval('public.players_id_seq'::regclass);


--
-- TOC entry 3382 (class 2604 OID 59806)
-- Name: races id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.races ALTER COLUMN id SET DEFAULT nextval('public.races_id_seq'::regclass);


--
-- TOC entry 3384 (class 2604 OID 59819)
-- Name: results id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.results ALTER COLUMN id SET DEFAULT nextval('public.results_id_seq'::regclass);


--
-- TOC entry 3376 (class 2604 OID 59775)
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- TOC entry 3708 (class 0 OID 59340)
-- Dependencies: 218
-- Data for Name: _nexora_metadata; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3745 (class 0 OID 60199)
-- Dependencies: 255
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3743 (class 0 OID 60097)
-- Dependencies: 253
-- Data for Name: arenas; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3736 (class 0 OID 59907)
-- Dependencies: 246
-- Data for Name: attendees; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3711 (class 0 OID 59451)
-- Dependencies: 221
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3738 (class 0 OID 59925)
-- Dependencies: 248
-- Data for Name: check_ins; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3730 (class 0 OID 59795)
-- Dependencies: 240
-- Data for Name: circuits; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3749 (class 0 OID 60256)
-- Dependencies: 259
-- Data for Name: colleges; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.colleges VALUES ('11111111-1111-1111-1111-111111111111', 'IIT Madras', 'Computer Science');
INSERT INTO public.colleges VALUES ('22222222-2222-2222-2222-222222222222', 'Anna University', 'Mechanical Engineering');
INSERT INTO public.colleges VALUES ('33333333-3333-3333-3333-333333333333', 'VIT Vellore', 'Electrical Engineering');
INSERT INTO public.colleges VALUES ('44444444-4444-4444-4444-444444444444', 'SRM Institute of Science and Technology', 'Civil Engineering');
INSERT INTO public.colleges VALUES ('55555555-5555-5555-5555-555555555555', 'Delhi University', 'Commerce');


--
-- TOC entry 3717 (class 0 OID 59614)
-- Dependencies: 227
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3748 (class 0 OID 60249)
-- Dependencies: 258
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3747 (class 0 OID 60242)
-- Dependencies: 257
-- Data for Name: countrys; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3742 (class 0 OID 60084)
-- Dependencies: 252
-- Data for Name: cricket_players; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.cricket_players VALUES (1, 'Virat Kohli', 37, 'Batsman', 1, 13000, 4);
INSERT INTO public.cricket_players VALUES (2, 'Rohit Sharma', 38, 'Batsman', 1, 11000, 8);
INSERT INTO public.cricket_players VALUES (3, 'Pat Cummins', 33, 'Bowler', 2, 1200, 250);
INSERT INTO public.cricket_players VALUES (4, 'Joe Root', 35, 'Batsman', 3, 10000, 30);
INSERT INTO public.cricket_players VALUES (5, 'Ben Stokes', 34, 'All-rounder', 3, 6000, 200);


--
-- TOC entry 3740 (class 0 OID 60075)
-- Dependencies: 250
-- Data for Name: cricket_teams; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.cricket_teams VALUES (1, 'India', 'India', 5, '2026-04-28 22:01:54.939757');
INSERT INTO public.cricket_teams VALUES (2, 'Australia', 'Australia', 8, '2026-04-28 22:01:54.939757');
INSERT INTO public.cricket_teams VALUES (3, 'England', 'England', 3, '2026-04-28 22:01:54.939757');


--
-- TOC entry 3728 (class 0 OID 59782)
-- Dependencies: 238
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3735 (class 0 OID 59897)
-- Dependencies: 245
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3744 (class 0 OID 60107)
-- Dependencies: 254
-- Data for Name: fighters; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3719 (class 0 OID 59630)
-- Dependencies: 229
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3718 (class 0 OID 59623)
-- Dependencies: 228
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3724 (class 0 OID 59671)
-- Dependencies: 234
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.matches VALUES (1, 1, 2, '2026-05-01', 2, 1);
INSERT INTO public.matches VALUES (2, 3, 1, '2026-05-05', 1, 1);


--
-- TOC entry 3712 (class 0 OID 59463)
-- Dependencies: 222
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3720 (class 0 OID 59637)
-- Dependencies: 230
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3713 (class 0 OID 59474)
-- Dependencies: 223
-- Data for Name: online_status; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3722 (class 0 OID 59657)
-- Dependencies: 232
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.players VALUES (1, 'Lionel Messi', 36, 'Forward', 1, '2026-04-25 16:34:16.989015');
INSERT INTO public.players VALUES (2, 'Karim Benzema', 36, 'Forward', 2, '2026-04-25 16:34:16.989015');
INSERT INTO public.players VALUES (3, 'Kevin De Bruyne', 32, 'Midfielder', 3, '2026-04-25 16:34:16.989015');


--
-- TOC entry 3716 (class 0 OID 59605)
-- Dependencies: 226
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3715 (class 0 OID 59590)
-- Dependencies: 225
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3732 (class 0 OID 59803)
-- Dependencies: 242
-- Data for Name: races; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3734 (class 0 OID 59816)
-- Dependencies: 244
-- Data for Name: results; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3709 (class 0 OID 59418)
-- Dependencies: 219
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3726 (class 0 OID 59772)
-- Dependencies: 236
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3737 (class 0 OID 59915)
-- Dependencies: 247
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3746 (class 0 OID 60211)
-- Dependencies: 256
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3714 (class 0 OID 59514)
-- Dependencies: 224
-- Data for Name: typing_indicators; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3710 (class 0 OID 59437)
-- Dependencies: 220
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- TOC entry 3766 (class 0 OID 0)
-- Dependencies: 239
-- Name: circuits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.circuits_id_seq', 1, false);


--
-- TOC entry 3767 (class 0 OID 0)
-- Dependencies: 251
-- Name: cricket_players_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cricket_players_id_seq', 5, true);


--
-- TOC entry 3768 (class 0 OID 0)
-- Dependencies: 249
-- Name: cricket_teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cricket_teams_id_seq', 3, true);


--
-- TOC entry 3769 (class 0 OID 0)
-- Dependencies: 237
-- Name: drivers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.drivers_id_seq', 1, false);


--
-- TOC entry 3770 (class 0 OID 0)
-- Dependencies: 233
-- Name: matches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matches_id_seq', 2, true);


--
-- TOC entry 3771 (class 0 OID 0)
-- Dependencies: 231
-- Name: players_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.players_id_seq', 3, true);


--
-- TOC entry 3772 (class 0 OID 0)
-- Dependencies: 241
-- Name: races_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.races_id_seq', 1, false);


--
-- TOC entry 3773 (class 0 OID 0)
-- Dependencies: 243
-- Name: results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.results_id_seq', 1, false);


--
-- TOC entry 3774 (class 0 OID 0)
-- Dependencies: 235
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.teams_id_seq', 1, false);


--
-- TOC entry 3419 (class 2606 OID 59349)
-- Name: _nexora_metadata _nexora_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._nexora_metadata
    ADD CONSTRAINT _nexora_metadata_pkey PRIMARY KEY (id);


--
-- TOC entry 3421 (class 2606 OID 59351)
-- Name: _nexora_metadata _nexora_metadata_table_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._nexora_metadata
    ADD CONSTRAINT _nexora_metadata_table_name_key UNIQUE (table_name);


--
-- TOC entry 3506 (class 2606 OID 60210)
-- Name: accounts accounts_account_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_account_number_key UNIQUE (account_number);


--
-- TOC entry 3508 (class 2606 OID 60208)
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 3500 (class 2606 OID 60106)
-- Name: arenas arenas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.arenas
    ADD CONSTRAINT arenas_pkey PRIMARY KEY (id);


--
-- TOC entry 3484 (class 2606 OID 59914)
-- Name: attendees attendees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT attendees_pkey PRIMARY KEY (id);


--
-- TOC entry 3435 (class 2606 OID 59462)
-- Name: channels channels_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_name_key UNIQUE (name);


--
-- TOC entry 3437 (class 2606 OID 59460)
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


--
-- TOC entry 3491 (class 2606 OID 59932)
-- Name: check_ins check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_pkey PRIMARY KEY (id);


--
-- TOC entry 3474 (class 2606 OID 59801)
-- Name: circuits circuits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.circuits
    ADD CONSTRAINT circuits_pkey PRIMARY KEY (id);


--
-- TOC entry 3519 (class 2606 OID 60262)
-- Name: colleges colleges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colleges
    ADD CONSTRAINT colleges_pkey PRIMARY KEY (id);


--
-- TOC entry 3456 (class 2606 OID 59622)
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- TOC entry 3517 (class 2606 OID 60255)
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- TOC entry 3515 (class 2606 OID 60248)
-- Name: countrys countrys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.countrys
    ADD CONSTRAINT countrys_pkey PRIMARY KEY (id);


--
-- TOC entry 3498 (class 2606 OID 60091)
-- Name: cricket_players cricket_players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cricket_players
    ADD CONSTRAINT cricket_players_pkey PRIMARY KEY (id);


--
-- TOC entry 3496 (class 2606 OID 60082)
-- Name: cricket_teams cricket_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cricket_teams
    ADD CONSTRAINT cricket_teams_pkey PRIMARY KEY (id);


--
-- TOC entry 3472 (class 2606 OID 59788)
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- TOC entry 3482 (class 2606 OID 59906)
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- TOC entry 3503 (class 2606 OID 60116)
-- Name: fighters fighters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fighters
    ADD CONSTRAINT fighters_pkey PRIMARY KEY (id);


--
-- TOC entry 3460 (class 2606 OID 59636)
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- TOC entry 3458 (class 2606 OID 59629)
-- Name: likes likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_pkey PRIMARY KEY (id);


--
-- TOC entry 3466 (class 2606 OID 59679)
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (id);


--
-- TOC entry 3442 (class 2606 OID 59473)
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- TOC entry 3462 (class 2606 OID 59645)
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- TOC entry 3446 (class 2606 OID 59482)
-- Name: online_status online_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_status
    ADD CONSTRAINT online_status_pkey PRIMARY KEY (id);


--
-- TOC entry 3464 (class 2606 OID 59664)
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- TOC entry 3454 (class 2606 OID 59613)
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- TOC entry 3452 (class 2606 OID 59599)
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- TOC entry 3476 (class 2606 OID 59809)
-- Name: races races_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.races
    ADD CONSTRAINT races_pkey PRIMARY KEY (id);


--
-- TOC entry 3478 (class 2606 OID 59822)
-- Name: results results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_pkey PRIMARY KEY (id);


--
-- TOC entry 3480 (class 2606 OID 59824)
-- Name: results results_race_id_driver_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_race_id_driver_id_key UNIQUE (race_id, driver_id);


--
-- TOC entry 3424 (class 2606 OID 59427)
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- TOC entry 3468 (class 2606 OID 59780)
-- Name: teams teams_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_name_key UNIQUE (name);


--
-- TOC entry 3470 (class 2606 OID 59778)
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- TOC entry 3489 (class 2606 OID 59924)
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- TOC entry 3513 (class 2606 OID 60218)
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- TOC entry 3450 (class 2606 OID 59521)
-- Name: typing_indicators typing_indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.typing_indicators
    ADD CONSTRAINT typing_indicators_pkey PRIMARY KEY (id);


--
-- TOC entry 3429 (class 2606 OID 59450)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3431 (class 2606 OID 59446)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3433 (class 2606 OID 59448)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3509 (class 1259 OID 60230)
-- Name: idx_accounts_account_number_0; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_accounts_account_number_0 ON public.accounts USING btree (account_number);


--
-- TOC entry 3510 (class 1259 OID 60231)
-- Name: idx_accounts_user_id_1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_accounts_user_id_1 ON public.accounts USING btree (user_id);


--
-- TOC entry 3501 (class 1259 OID 60117)
-- Name: idx_arenas_name_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_arenas_name_0 ON public.arenas USING btree (name);


--
-- TOC entry 3485 (class 1259 OID 59963)
-- Name: idx_attendees_event_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendees_event_id_0 ON public.attendees USING btree (event_id);


--
-- TOC entry 3486 (class 1259 OID 59964)
-- Name: idx_attendees_user_id_1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attendees_user_id_1 ON public.attendees USING btree (user_id);


--
-- TOC entry 3438 (class 1259 OID 59505)
-- Name: idx_channels_name_0; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_channels_name_0 ON public.channels USING btree (name);


--
-- TOC entry 3492 (class 1259 OID 59967)
-- Name: idx_check_ins_attendee_id_1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_check_ins_attendee_id_1 ON public.check_ins USING btree (attendee_id);


--
-- TOC entry 3493 (class 1259 OID 59966)
-- Name: idx_check_ins_event_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_check_ins_event_id_0 ON public.check_ins USING btree (event_id);


--
-- TOC entry 3494 (class 1259 OID 59968)
-- Name: idx_check_ins_ticket_id_2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_check_ins_ticket_id_2 ON public.check_ins USING btree (ticket_id);


--
-- TOC entry 3504 (class 1259 OID 60118)
-- Name: idx_fighters_weight_class_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fighters_weight_class_0 ON public.fighters USING btree (weight_class);


--
-- TOC entry 3439 (class 1259 OID 59506)
-- Name: idx_messages_channel_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_channel_id_0 ON public.messages USING btree (channel_id);


--
-- TOC entry 3440 (class 1259 OID 59507)
-- Name: idx_messages_user_id_1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_user_id_1 ON public.messages USING btree (user_id);


--
-- TOC entry 3443 (class 1259 OID 59509)
-- Name: idx_online_status_channel_id_1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_online_status_channel_id_1 ON public.online_status USING btree (channel_id);


--
-- TOC entry 3444 (class 1259 OID 59508)
-- Name: idx_online_status_user_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_online_status_user_id_0 ON public.online_status USING btree (user_id);


--
-- TOC entry 3422 (class 1259 OID 59434)
-- Name: idx_tasks_category_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_category_id_0 ON public.tasks USING btree (category_id);


--
-- TOC entry 3487 (class 1259 OID 59965)
-- Name: idx_tickets_event_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_event_id_0 ON public.tickets USING btree (event_id);


--
-- TOC entry 3511 (class 1259 OID 60232)
-- Name: idx_transactions_account_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_account_id_0 ON public.transactions USING btree (account_id);


--
-- TOC entry 3447 (class 1259 OID 59532)
-- Name: idx_typing_indicators_channel_id_0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_typing_indicators_channel_id_0 ON public.typing_indicators USING btree (channel_id);


--
-- TOC entry 3448 (class 1259 OID 59533)
-- Name: idx_typing_indicators_user_id_1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_typing_indicators_user_id_1 ON public.typing_indicators USING btree (user_id);


--
-- TOC entry 3425 (class 1259 OID 60229)
-- Name: idx_users_email_0; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_users_email_0 ON public.users USING btree (email);


--
-- TOC entry 3426 (class 1259 OID 59504)
-- Name: idx_users_email_1; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_users_email_1 ON public.users USING btree (email);


--
-- TOC entry 3427 (class 1259 OID 59503)
-- Name: idx_users_username_0; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_users_username_0 ON public.users USING btree (username);


--
-- TOC entry 3550 (class 2620 OID 60233)
-- Name: accounts accounts_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER accounts_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.accounts FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- TOC entry 3547 (class 2620 OID 59969)
-- Name: attendees attendees_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER attendees_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.attendees FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- TOC entry 3542 (class 2620 OID 59510)
-- Name: channels channels_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER channels_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.channels FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- TOC entry 3548 (class 2620 OID 59970)
-- Name: check_ins check_ins_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER check_ins_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.check_ins FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- TOC entry 3549 (class 2620 OID 60239)
-- Name: cricket_players cricket_players_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cricket_players_trigger AFTER INSERT ON public.cricket_players FOR EACH ROW EXECUTE FUNCTION public.notify_cricket_change();


--
-- TOC entry 3546 (class 2620 OID 60119)
-- Name: matches matches_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER matches_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.matches FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- TOC entry 3543 (class 2620 OID 59511)
-- Name: messages messages_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER messages_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.messages FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- TOC entry 3544 (class 2620 OID 59512)
-- Name: online_status online_status_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER online_status_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.online_status FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- TOC entry 3541 (class 2620 OID 59436)
-- Name: tasks tasks_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tasks_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- TOC entry 3551 (class 2620 OID 60234)
-- Name: transactions transactions_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER transactions_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- TOC entry 3545 (class 2620 OID 59534)
-- Name: typing_indicators typing_indicators_realtime_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER typing_indicators_realtime_trigger AFTER INSERT OR DELETE OR UPDATE ON public.typing_indicators FOR EACH ROW EXECUTE FUNCTION public.notify_database_change();


--
-- TOC entry 3538 (class 2606 OID 60092)
-- Name: cricket_players cricket_players_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cricket_players
    ADD CONSTRAINT cricket_players_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.cricket_teams(id) ON DELETE SET NULL;


--
-- TOC entry 3527 (class 2606 OID 59789)
-- Name: drivers drivers_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- TOC entry 3539 (class 2606 OID 60219)
-- Name: accounts fk_accounts_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT fk_accounts_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3532 (class 2606 OID 59933)
-- Name: attendees fk_attendees_event_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT fk_attendees_event_id FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- TOC entry 3533 (class 2606 OID 59938)
-- Name: attendees fk_attendees_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT fk_attendees_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3535 (class 2606 OID 59953)
-- Name: check_ins fk_check_ins_attendee_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT fk_check_ins_attendee_id FOREIGN KEY (attendee_id) REFERENCES public.attendees(id) ON DELETE CASCADE;


--
-- TOC entry 3536 (class 2606 OID 59948)
-- Name: check_ins fk_check_ins_event_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT fk_check_ins_event_id FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- TOC entry 3537 (class 2606 OID 59958)
-- Name: check_ins fk_check_ins_ticket_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT fk_check_ins_ticket_id FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- TOC entry 3520 (class 2606 OID 59483)
-- Name: messages fk_messages_channel_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_messages_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE CASCADE;


--
-- TOC entry 3521 (class 2606 OID 59488)
-- Name: messages fk_messages_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_messages_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3522 (class 2606 OID 59498)
-- Name: online_status fk_online_status_channel_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_status
    ADD CONSTRAINT fk_online_status_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE CASCADE;


--
-- TOC entry 3523 (class 2606 OID 59493)
-- Name: online_status fk_online_status_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_status
    ADD CONSTRAINT fk_online_status_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3534 (class 2606 OID 59943)
-- Name: tickets fk_tickets_event_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT fk_tickets_event_id FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- TOC entry 3540 (class 2606 OID 60224)
-- Name: transactions fk_transactions_account_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_transactions_account_id FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON DELETE CASCADE;


--
-- TOC entry 3524 (class 2606 OID 59522)
-- Name: typing_indicators fk_typing_indicators_channel_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.typing_indicators
    ADD CONSTRAINT fk_typing_indicators_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE CASCADE;


--
-- TOC entry 3525 (class 2606 OID 59527)
-- Name: typing_indicators fk_typing_indicators_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.typing_indicators
    ADD CONSTRAINT fk_typing_indicators_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3526 (class 2606 OID 59600)
-- Name: projects projects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3528 (class 2606 OID 59810)
-- Name: races races_circuit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.races
    ADD CONSTRAINT races_circuit_id_fkey FOREIGN KEY (circuit_id) REFERENCES public.circuits(id) ON DELETE CASCADE;


--
-- TOC entry 3529 (class 2606 OID 59830)
-- Name: results results_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE CASCADE;


--
-- TOC entry 3530 (class 2606 OID 59825)
-- Name: results results_race_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_race_id_fkey FOREIGN KEY (race_id) REFERENCES public.races(id) ON DELETE CASCADE;


--
-- TOC entry 3531 (class 2606 OID 59835)
-- Name: results results_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- TOC entry 3706 (class 0 OID 60199)
-- Dependencies: 255
-- Name: accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3704 (class 0 OID 59907)
-- Dependencies: 246
-- Name: attendees; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.attendees ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3698 (class 0 OID 59451)
-- Dependencies: 221
-- Name: channels; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.channels ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3705 (class 0 OID 59925)
-- Dependencies: 248
-- Name: check_ins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.check_ins ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3702 (class 0 OID 59671)
-- Dependencies: 234
-- Name: matches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.matches ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3699 (class 0 OID 59463)
-- Dependencies: 222
-- Name: messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3700 (class 0 OID 59474)
-- Dependencies: 223
-- Name: online_status; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.online_status ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3703 (class 0 OID 59803)
-- Dependencies: 242
-- Name: races; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.races ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3696 (class 0 OID 59418)
-- Dependencies: 219
-- Name: tasks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3707 (class 0 OID 60211)
-- Dependencies: 256
-- Name: transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3701 (class 0 OID 59514)
-- Dependencies: 224
-- Name: typing_indicators; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.typing_indicators ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 3697 (class 0 OID 59437)
-- Dependencies: 220
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Completed on 2026-05-13 13:29:28

--
-- PostgreSQL database dump complete
--

\unrestrict AzQzG3jIkrh9PTTogdUUHdbmHmdONETxdF4BUNiHela8Qcasc87ijqRl29BM1F0

